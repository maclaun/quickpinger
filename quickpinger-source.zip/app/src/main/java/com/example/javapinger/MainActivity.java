package com.example.javapinger;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText addressEditText;
    private Button pingButton;
    private TextView statusTextView;
    private TextView pingTimeTextView;
    private TextView historyTextView;
    private View statusDot;
    
    private ExecutorService executorService;
    private ToneGenerator toneGenerator;
    private Vibrator vibrator;
    private SharedPreferences sharedPreferences;

    private static final String PREFS_NAME = "CyberPingerPrefs";
    private static final String HISTORY_KEY = "ping_history";
    private static final int PING_COUNT = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addressEditText = findViewById(R.id.addressEditText);
        pingButton = findViewById(R.id.pingButton);
        statusTextView = findViewById(R.id.statusTextView);
        pingTimeTextView = findViewById(R.id.pingTimeTextView);
        statusDot = findViewById(R.id.statusDot);
        historyTextView = findViewById(R.id.historyTextView);

        executorService = Executors.newSingleThreadExecutor();
        toneGenerator = new ToneGenerator(AudioManager.STREAM_SYSTEM, 100);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        pingButton.setOnClickListener(v -> performPing());
        
        // Feature 4: Server Randomizer (Long Click)
        pingButton.setOnLongClickListener(v -> {
            if (addressEditText.getText().toString().trim().isEmpty()) {
                List<String> premiumServers = Arrays.asList(
                    "8.8.8.8", "1.1.1.1", "192.168.1.1", 
                    "162.254.196.1", "core.rust-servers.net"
                );
                String randomServer = premiumServers.get(new Random().nextInt(premiumServers.size()));
                addressEditText.setText(randomServer);
                Toast.makeText(this, "Wylosowano serwer premium!", Toast.LENGTH_SHORT).show();
                vibrate(new long[]{0, 50}, -1);
                return true;
            }
            return false;
        });

        loadHistory();
    }

    private void performPing() {
        final String address = addressEditText.getText().toString().trim();

        if (address.isEmpty()) {
            Toast.makeText(this, "Adres IP / URL nie może быть pusty!", Toast.LENGTH_SHORT).show();
            return;
        }

        // UI State: DIAGNOSING
        statusTextView.setText("DIAGNOSING...");
        statusTextView.setTextColor(Color.parseColor("#F59E0B"));
        statusDot.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#F59E0B")));
        pingTimeTextView.setText("STRESS_TEST: IN_PROGRESS...");
        pingTimeTextView.setTextColor(Color.WHITE);

        executorService.execute(() -> {
            List<Long> latencies = new ArrayList<>();
            int successCount = 0;

            try {
                for (int i = 0; i < PING_COUNT; i++) {
                    long startTime = System.currentTimeMillis();
                    boolean reachable = InetAddress.getByName(address).isReachable(2000);
                    long endTime = System.currentTimeMillis();
                    
                    if (reachable) {
                        latencies.add(endTime - startTime);
                        successCount++;
                    }
                    Thread.sleep(100); // Small interval between pings
                }

                final int finalSuccessCount = successCount;
                runOnUiThread(() -> {
                    if (finalSuccessCount > 0) {
                        long min = Collections.min(latencies);
                        long max = Collections.max(latencies);
                        long sum = 0;
                        for (long l : latencies) sum += l;
                        long avg = sum / latencies.size();
                        int loss = ((PING_COUNT - finalSuccessCount) * 100) / PING_COUNT;

                        String result = String.format(Locale.US, "AVG: %d ms // MIN: %d ms // MAX: %d ms // LOSS: %d%%", avg, min, max, loss);
                        
                        statusTextView.setText("SYSTEM_ONLINE");
                        statusTextView.setTextColor(Color.parseColor("#10B981"));
                        statusDot.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#10B981")));
                        pingTimeTextView.setText(result);
                        
                        // Feature 2 & 3: Audio & Haptic
                        playPingSound(avg);
                        vibrate(new long[]{0, 30}, -1);
                        
                        saveToHistory(address, avg, "ONLINE");
                    } else {
                        handleFailure(address);
                    }
                });

            } catch (Exception e) {
                runOnUiThread(() -> handleFailure(address));
            }
        });
    }

    private void handleFailure(String address) {
        statusTextView.setText("HOST_UNREACHABLE");
        statusTextView.setTextColor(Color.parseColor("#EF4444"));
        statusDot.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#EF4444")));
        pingTimeTextView.setText("--- ms // LOSS: 100%");
        pingTimeTextView.setTextColor(Color.parseColor("#7F1D1D"));

        // Feature 2 & 3: Audio & Haptic Failure
        toneGenerator.startTone(ToneGenerator.TONE_CDMA_PIP, 300);
        vibrate(new long[]{0, 200, 100, 200}, -1);
        
        saveToHistory(address, 0, "OFFLINE");
        Toast.makeText(this, "Host jest nieosiągalny!", Toast.LENGTH_SHORT).show();
    }

    private void playPingSound(long avgPing) {
        int duration = (avgPing < 30) ? 50 : 150;
        toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP, duration);
    }

    private void vibrate(long[] pattern, int repeat) {
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (pattern.length == 2 && pattern[0] == 0) {
                vibrator.vibrate(VibrationEffect.createOneShot(pattern[1], VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, repeat));
            }
        } else {
            vibrator.vibrate(pattern, repeat);
        }
    }

    private void saveToHistory(String address, long avg, String status) {
        String timestamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        String entry = String.format(Locale.getDefault(), "[%s] %s — %dms (%s)", timestamp, address, avg, status);
        
        Log.d("CyberPinger", entry);

        String currentHistory = sharedPreferences.getString(HISTORY_KEY, "");
        List<String> logs = new ArrayList<>(Arrays.asList(currentHistory.split("\n")));
        logs.removeAll(Arrays.asList("", null));
        
        if (logs.size() >= 5) logs.remove(0);
        logs.add(entry);

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < logs.size(); i++) {
            sb.append(logs.get(i));
            if (i < logs.size() - 1) sb.append("\n");
        }
        
        sharedPreferences.edit().putString(HISTORY_KEY, sb.toString()).apply();
        loadHistory();
    }

    private void loadHistory() {
        String history = sharedPreferences.getString(HISTORY_KEY, "[NO DATA]");
        if (history.isEmpty()) history = "[NO DATA]";
        historyTextView.setText(history);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executorService != null) executorService.shutdown();
        if (toneGenerator != null) toneGenerator.release();
    }
}
